<?php $__env->startSection('title', 'Register'); ?>

<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row">
        <div class="col-md-10 col-md-offset-1">
            <div class="panel panel-default">
                <div class="panel-heading"><?php echo e(isset($user) ? 'Editer' : 'Ajouter'); ?> un utilisateur</div>

                <div class="panel-body">
	
                	<?php echo e(Form::open(['url' => isset($user) ? '/user/'.$user->id  :  '/user', 'method' => isset($user) ? 'put' : 'post'])); ?>

                	    <div class="form-group">
                		<?php echo e(Form::label('email','Mail :',['class'=>'registerForm'])); ?>

                		<?php echo e(Form::email('email', isset($user) ? $user->email : null,['class'=>'form-control'])); ?><br/><?php echo $errors->first('email','<small class="help-block">:message</small>'); ?>

                        </div>
                	    <div class="form-group">
                		<?php echo e(Form::label('name','Prenom :',['class'=>'registerForm'])); ?>

                		<?php echo e(Form::text('name',isset($user) ? $user->name : null,['class'=>'form-control'])); ?><br/><?php echo $errors->first('name','<small class="help-block">:message</small>'); ?>

                        </div>
                	    <div class="form-group">
                		<?php echo e(Form::label('surname','Nom :', ['class'=>'registerForm'])); ?>

                		<?php echo e(Form::text('surname',isset($user) ? $user->surname : null,['class'=>'form-control'])); ?><br/><?php echo $errors->first('surname','<small class="help-block">:message</small>'); ?>

                        </div>
                		<div class="form-group">
                		<?php echo e(Form::label('password','Mot de passe :',['class'=>'registerForm'])); ?>

                		<?php echo e(Form::password('password',['class'=>'form-control'])); ?><br/><?php echo $errors->first('password','<small class="help-block">:message</small>'); ?>

                        </div>
                        <div class="form-group">
                		<?php echo e(Form::label('password_confirmation','Confirmation :',['class'=>'registerForm'])); ?>

                		<?php echo e(Form::password('password_confirmation',['class'=>'form-control'])); ?><br/><?php echo $errors->first('password_confirmation','<small class="help-block">:message</small>'); ?>

                        </div>
                		<?php echo e(form::hidden('id',isset($user) ? $user->id : null)); ?>

                		<?php echo e(Form::submit(isset($user) ? 'Editer' : 'Ajouter',['class'=>'btn btn-success pull-right'])); ?>

                	<?php echo e(Form::close()); ?>

                </div>
            </div>
        </div>
    </div>
</div>
	
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>