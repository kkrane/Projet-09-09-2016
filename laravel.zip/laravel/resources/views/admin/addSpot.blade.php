@extends('templates.adminTemplate')


@section('content')
<div>
	{{ Form::open() }}
		{{ Form::label('num', 'N° place :',['class'=>'addSpotForm']) }}
		{{Form::text('num', $lastSpot->num)}}<br/>
		{!! $errors->first('num','<small class="help-block">:message</small>') !!}
		{{Form::label('floor', "Etage :",['class'=>'addSpotForm'])}}
		{{Form::text('floor')}}<br/>
		{!! $errors->first('floor','<small class="help-block">:message</small>') !!}
		{{Form::label('type','Type : ',['class'=>'addSpotForm'])}}
		{{Form::radio('type', 0,true)}}<span>Normale</span>
		{{Form::radio('type', 1)}}<span>Moto</span>
		{{Form::radio('type', 2)}}<span>Handicapée</span><br/>
		{{Form::submit('Ajouter',[])}}
	{{Form::close()}}
</div>
@endsection