<?php $__env->startSection('content'); ?>
<div>
	<?php echo e(Form::open(['url' => isset($spot) ? '/spot/'.$spot->id  :  '/spot', 'method' => isset($spot) ? 'put' : 'post'])); ?>

		<?php echo e(Form::label('num', 'N° place :',['class'=>'addSpotForm'])); ?>

		<?php echo e(Form::text('num',isset($spot) ? $spot->num : null)); ?><br/>
		<?php echo $errors->first('num','<small class="help-block">:message</small>'); ?>

		<?php if(session()->has('taken')): ?>
            <small class="help-block">Cette place existe deajà</small>
        <?php endif; ?>
        <?php if(!isset($spot)): ?>
		    <?php echo e(Form::label('floor', "Etage :",['class'=>'addSpotForm'])); ?>

    		<?php echo e(Form::text('floor',isset($spot) ? $spot->num : null)); ?><br/>
        <?php endif; ?>
		<?php echo $errors->first('floor','<small class="help-block">:message</small>'); ?>

		<?php echo e(Form::label('type','Type : ',['class'=>'addSpotForm'])); ?>

		<?php echo e(Form::radio('type', 0)); ?><span>Normale</span>
		<?php echo e(Form::radio('type', 1)); ?><span>Moto</span>
		<?php echo e(Form::radio('type', 2)); ?><span>Handicapée</span><br/>
		<?php echo e(Form::submit('Ajouter',[])); ?>

	<?php echo e(Form::close()); ?>

</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>