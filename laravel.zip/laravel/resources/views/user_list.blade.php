@extends('layouts.app')

@section('title')

@section('content')

@if(isset($deleted))
<p>L'utilisateur {{$deleted}} a été effacé avec succès!</p>
@endif

<button class="btn btn-primary pull-right">{!!Html::linkRoute('user.create','Ajouter un utilisateur')!!}</button>
<table class="table">
	<tr>
		<th>Nom</th>
		<th>Prénom</th>
		<th>Statut</th>
		<th></th>
		<th></th>
		<th></th>
	</tr>

@foreach($users as $user)
	<tr>
		<td>{{Html::linkRoute('user.show',$user->surname,['id'=>$user->id])}}</td>
		<td>{{$user->name}}</td>
		<td>{{$user->status}}</td>
		<td>{{Html::linkRoute('user.edit','Editer',['id'=>$user->id])}}
		<td>
		@if($user->status != 2)
		    {{Form::open(['route'=>['user.destroy', $user->id],'method'=>'DELETE'])}}
				{{Form::submit('Supprimer', ['class' => 'btn btn-danger'])}}
				{{Form::hidden('id', $user->id)}}
			{{Form::close()}}
		@endif
		</td>
        <td>
		@if($user->status == 0)
				{{Html::linkRoute('user.validation','Valider',['id'=>$user->id])}}
        @endif
        </td>
	</tr>
@endforeach
@endsection


@section('js')
<script>
       $('.btn-danger').click(function(){
          return confirm('Etes vous sûr de vouloir effacer cet utilisateur?');
       });
</script>

@endsection