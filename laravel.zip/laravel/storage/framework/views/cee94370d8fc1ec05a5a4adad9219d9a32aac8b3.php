<?php $__env->startSection('title'); ?>

<?php $__env->startSection('content'); ?>

<?php if(isset($deleted)): ?>
<p>L'utilisateur <?php echo e($deleted); ?> a été effacé avec succès!</p>
<?php endif; ?>

<button class="btn btn-primary pull-right"><?php echo Html::linkRoute('user.create','Ajouter un utilisateur'); ?></button>
<table class="table">
	<tr>
		<th>Nom</th>
		<th>Prénom</th>
		<th>Statut</th>
		<th></th>
		<th></th>
		<th></th>
	</tr>

<?php foreach($users as $user): ?>
	<tr>
		<td><?php echo e(Html::linkRoute('user.show',$user->surname,['id'=>$user->id])); ?></td>
		<td><?php echo e($user->name); ?></td>
		<td><?php echo e($user->status); ?></td>
		<td><?php echo e(Html::linkRoute('user.edit','Editer',['id'=>$user->id])); ?>

		<td>
		<?php if($user->status != 2): ?>
		    <?php echo e(Form::open(['route'=>['user.destroy', $user->id],'method'=>'DELETE'])); ?>

				<?php echo e(Form::submit('Supprimer', ['class' => 'btn btn-danger'])); ?>

				<?php echo e(Form::hidden('id', $user->id)); ?>

			<?php echo e(Form::close()); ?>

		<?php endif; ?>
		</td>
        <td>
		<?php if($user->status == 0): ?>
				<?php echo e(Html::linkRoute('user.validation','Valider',['id'=>$user->id])); ?>

        <?php endif; ?>
        </td>
	</tr>
<?php endforeach; ?>
<?php $__env->stopSection(); ?>


<?php $__env->startSection('js'); ?>
<script>
       $('.btn-danger').click(function(){
          return confirm('Etes vous sûr de vouloir effacer cet utilisateur?');
       });
</script>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>