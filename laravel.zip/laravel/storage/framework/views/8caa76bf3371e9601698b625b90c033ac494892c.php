<?php $__env->startSection('title', 'Register'); ?>

<?php $__env->startSection('content'); ?>
	
	<?php echo e(Form::open(['url' => isset($user) ? '/user/'.$user->id  :  '/user', 'method' => isset($user) ? 'put' : 'post'])); ?>

		<?php echo e(Form::label('email','Mail :',['class'=>'registerForm'])); ?>

		<?php echo e(Form::email('email', $user ? $user->email : null)); ?><br/><?php echo $errors->first('email','<small class="help-block">:message</small>'); ?>

		<?php echo e(Form::label('name','Prenom :',['class'=>'registerForm'])); ?>

		<?php echo e(Form::text('name',$user ? $user->name : null)); ?><br/><?php echo $errors->first('name','<small class="help-block">:message</small>'); ?>

		<?php echo e(Form::label('surname','Nom :', ['class'=>'registerForm'])); ?>

		<?php echo e(Form::text('surname',$user ? $user->surname : null)); ?><br/><?php echo $errors->first('surname','<small class="help-block">:message</small>'); ?>

		<?php echo e(Form::label('password','Mot de passe :',['class'=>'registerForm'])); ?>

		<?php echo e(Form::password('password')); ?><br/><?php echo $errors->first('password','<small class="help-block">:message</small>'); ?>

		<?php echo e(Form::label('password_confirmation','Confirmation :',['class'=>'registerForm'])); ?>

		<?php echo e(Form::password('password_confirmation')); ?><br/><?php echo $errors->first('password_confirmation','<small class="help-block">:message</small>'); ?>

		<?php echo e(form::hidden('id',$user ? $user->id : null)); ?>

		<?php echo e(Form::submit()); ?>

	<?php echo e(Form::close()); ?>

	
<?php $__env->stopSection(); ?>
<?php echo $__env->make('templates.baseTemplate', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>