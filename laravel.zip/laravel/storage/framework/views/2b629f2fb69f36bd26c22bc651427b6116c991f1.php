<?php $__env->startSection('title'); ?>

<?php $__env->startSection('content'); ?>

<?php if(isset($deleted)): ?>
<p>L'utilisateur <?php echo e($deleted); ?> a été effacé avec succès!</p>
<?php endif; ?>

<button class="btn btn-primary pull-right"><?php echo Html::linkRoute('spot.create','Ajouter une place'); ?></button>
<table class="table">
	<tr>
		<th>Numéro</th>
		<th>Etage</th>
		<th>Statut</th>
		<th>Utilisateur</th>
		<th>Type</th>
		<th></th>
		<th></th>
	</tr>

<?php foreach($spots as $spot): ?>
	<tr>
		<td><?php echo e(Html::linkRoute('spot.show',$spot->num,['id'=>$spot->id])); ?></td>
		<td><?php echo e($spot->floor); ?></td>
		<td><?php echo e($spot->status); ?></td>
		<td><?php echo e($spot->user_id); ?></td>
		<td><?php echo e($spot->type); ?></td>
		<td><?php echo e(Html::linkRoute('spot.edit','Editer',['id'=>$spot->id])); ?>

		<td>
        <?php echo e(Form::open(['route'=>['spot.destroy', $spot->id],'method'=>'DELETE'])); ?>

            <?php echo e(Form::submit('Supprimer', ['class' => 'btn btn-danger'])); ?>

            <?php echo e(Form::hidden('id', $spot->id)); ?>

        <?php echo e(Form::close()); ?>

		</td>
	</tr>
<?php endforeach; ?>
<?php $__env->stopSection(); ?>


<?php $__env->startSection('js'); ?>
<script>
       $('.btn-danger').click(function(){
          return confirm('Etes vous sûr de vouloir effacer cette place?');
       });
</script>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>