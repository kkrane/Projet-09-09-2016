<?php $__env->startSection('title', 'Login'); ?>

<?php $__env->startSection('content'); ?>
<?php echo e($user->name); ?>

<?php echo e(Form::open()); ?>

    <?php echo e(Form::label('email')); ?>

    <?php echo e(Form::text('email')); ?>

    <?php echo e(Form::label('password')); ?>

    <?php echo e(Form::password('password')); ?>

<?php echo e(Form::close()); ?>



<?php $__env->stopSection(); ?>
<?php echo $__env->make('templates.baseTemplate', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>