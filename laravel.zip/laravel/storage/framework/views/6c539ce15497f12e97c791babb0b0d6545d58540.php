<?php $__env->startSection('title'); ?>

<?php $__env->startSection('content'); ?>


<div class="col-md-8 col-md-offset-2">
    <table class="table">
    	<tr>
    		<th>ID</th>
    		<th>Utilisateur</th>
    		<th>Message</th>
    		<th>Vu</th>
    		<th></th>
    		<th></th>
    	</tr>    

    <?php foreach($tickets as $ticket): ?>
    	<tr>
    		<td><?php echo e(Html::linkRoute('ticket.show',$ticket->id,['id'=>$ticket->id])); ?></td>
    		<td><?php echo e($ticket->user->name); ?> <?php echo e($ticket->user->surname); ?></td>
            <td><?php echo e(substr($ticket->message,0,100)); ?></td>
    		<td><?php echo e($ticket->seen); ?></td>
    		<td>
    		    <?php echo e(Form::open(['route'=>['ticket.destroy', $ticket->id],'method'=>'DELETE'])); ?>

    				<?php echo e(Form::submit('Supprimer', ['class' => 'btn btn-danger'])); ?>

    				<?php echo e(Form::hidden('id', $ticket->id)); ?>

    			<?php echo e(Form::close()); ?>

    		</td>
    	</tr>
    <?php endforeach; ?>
    </table>
</div>
<?php $__env->stopSection(); ?>


<?php $__env->startSection('js'); ?>
<script>
       $('.btn-danger').click(function(){
          return confirm('Etes vous sûr de vouloir effacer ce ticket?');
       });
</script>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>