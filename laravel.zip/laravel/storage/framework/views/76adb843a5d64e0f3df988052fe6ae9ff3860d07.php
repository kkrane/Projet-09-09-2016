<?php $__env->startSection('content'); ?>
<div>
<?php echo e(Form::open()); ?>

	<?php echo e(Form::label('num', 'N° place :',['class'=>'addSpotForm'])); ?>

	<?php echo e(Form::text('num', $lastSpot->num)); ?><br/>
	<?php echo $errors->first('num','<small class="help-block">:message</small>'); ?>

	<?php echo e(Form::label('floor', "Etage :",['class'=>'addSpotForm'])); ?>

	<?php echo e(Form::text('floor')); ?><br/>
	<?php echo $errors->first('floor','<small class="help-block">:message</small>'); ?>

	<?php echo e(Form::label('type','Type : ',['class'=>'addSpotForm'])); ?>

	<?php echo e(Form::radio('type', 0,true)); ?><span>Normale</span>
	<?php echo e(Form::radio('type', 1)); ?><span>Moto</span>
	<?php echo e(Form::radio('type', 2)); ?><span>Handicapée</span><br/>
	<?php echo e(Form::submit('Ajouter',[])); ?>

<?php echo e(Form::close()); ?>

</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('templates.adminTemplate', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>