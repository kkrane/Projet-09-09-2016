@extends('templates.baseTemplate')

@section('title', 'Register')

@section('content')
	
	{{Form::open(['url' => isset($user) ? '/user/'.$user->id  :  '/user', 'method' => isset($user) ? 'put' : 'post'])}}
		{{Form::label('email','Mail :',['class'=>'registerForm'])}}
		{{Form::email('email', $user ? $user->email : null)}}<br/>{!! $errors->first('email','<small class="help-block">:message</small>') !!}
		{{Form::label('name','Prenom :',['class'=>'registerForm'])}}
		{{Form::text('name',$user ? $user->name : null)}}<br/>{!! $errors->first('name','<small class="help-block">:message</small>') !!}
		{{Form::label('surname','Nom :', ['class'=>'registerForm'])}}
		{{Form::text('surname',$user ? $user->surname : null)}}<br/>{!! $errors->first('surname','<small class="help-block">:message</small>') !!}
		{{Form::label('password','Mot de passe :',['class'=>'registerForm'])}}
		{{Form::password('password')}}<br/>{!! $errors->first('password','<small class="help-block">:message</small>') !!}
		{{Form::label('password_confirmation','Confirmation :',['class'=>'registerForm'])}}
		{{Form::password('password_confirmation')}}<br/>{!! $errors->first('password_confirmation','<small class="help-block">:message</small>') !!}
		{{form::hidden('id',$user ? $user->id : null)}}
		{{Form::submit()}}
	{{Form::close()}}
	
@endsection