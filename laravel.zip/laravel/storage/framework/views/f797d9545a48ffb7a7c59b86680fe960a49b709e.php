<?php $__env->startSection('title', 'Register'); ?>

<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row">
        <div class="col-md-10 col-md-offset-1">
            <div class="panel panel-default">
                <div class="panel-heading">Contacter l'administrateur</div>

                <div class="panel-body">
	
                	<?php echo e(Form::open(['route' => 'ticket.store', 'method' => 'post'])); ?>

                	    <div class="form-group">
                		<?php echo e(Form::label('message','Votre message')); ?>

                		<?php echo e(Form::textarea('message', null,['class'=>'form-control','rows'=>'8'])); ?><br/><?php echo $errors->first('message','<small class="help-block">:message</small>'); ?>

                		<?php echo e(form::hidden('id',isset($user) ? $user->id : null)); ?>

                		<?php echo e(Form::submit(isset($user) ? 'Editer' : 'Ajouter',['class'=>'btn btn-success pull-right'])); ?>

                	<?php echo e(Form::close()); ?>

                </div>
            </div>
        </div>
    </div>
</div>
	
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>